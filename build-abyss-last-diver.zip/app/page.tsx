import AbyssGame from '@/components/abyss/abyss-game'

export default function Page() {
  return <AbyssGame />
}

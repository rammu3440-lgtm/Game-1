export class OceanAudio {
  context: AudioContext | null = null
  master: GainNode | null = null
  muted = false
  private breathTimer: ReturnType<typeof setInterval> | null = null
  start() {
    if (this.context) { void this.context.resume(); return }
    try {
      this.context = new AudioContext()
      const ctx = this.context
      this.master = ctx.createGain(); this.master.gain.value = this.muted ? 0 : .35; this.master.connect(ctx.destination)
      const buffer = ctx.createBuffer(1, ctx.sampleRate * 4, ctx.sampleRate), channel = buffer.getChannelData(0)
      let last = 0
      for (let i = 0; i < channel.length; i++) { last = (last + (Math.random() * 2 - 1) * .02) / 1.02; channel[i] = last * 4 }
      const noise = ctx.createBufferSource(); noise.buffer = buffer; noise.loop = true
      const filter = ctx.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = 360
      const volume = ctx.createGain(); volume.gain.value = .45
      noise.connect(filter); filter.connect(volume); volume.connect(this.master); noise.start()
      const drone = ctx.createOscillator(), droneGain = ctx.createGain(); drone.frequency.value = 43; droneGain.gain.value = .09; drone.connect(droneGain); droneGain.connect(this.master); drone.start()
      this.breathTimer = setInterval(() => this.tone(125, 1.4, .035, 'sine', 80), 4400)
    } catch { this.context = null }
  }
  tone(frequency: number, seconds: number, volume: number, type: OscillatorType = 'sine', end = frequency) {
    if (!this.context || !this.master) return
    const ctx = this.context, oscillator = ctx.createOscillator(), gain = ctx.createGain(), now = ctx.currentTime
    oscillator.type = type; oscillator.frequency.setValueAtTime(frequency, now); oscillator.frequency.exponentialRampToValueAtTime(Math.max(1, end), now + seconds)
    gain.gain.setValueAtTime(.001, now); gain.gain.exponentialRampToValueAtTime(volume, now + .06); gain.gain.exponentialRampToValueAtTime(.001, now + seconds)
    oscillator.connect(gain); gain.connect(this.master); oscillator.start(now); oscillator.stop(now + seconds)
    oscillator.onended = () => { oscillator.disconnect(); gain.disconnect() }
  }
  event = (kind: string, text?: string) => {
    if (kind === 'scan') this.tone(1700, 1.1, .13, 'sine', 250)
    if (kind === 'complete') { this.tone(540, .3, .07); setTimeout(() => this.tone(810, .4, .06), 170) }
    if (kind === 'click') this.tone(340, .12, .035)
    if (kind === 'impact') { this.tone(75, 1.6, .3, 'sawtooth', 24); this.tone(180, .4, .1, 'triangle', 40) }
    if (kind === 'ending') this.tone(130, 4, .2, 'sine', 260)
    if (kind === 'radio') { this.tone(820, .13, .06, 'square'); if (text) this.speak(text) }
  }
  speak(text: string) {
    if (this.muted || typeof speechSynthesis === 'undefined') return
    speechSynthesis.cancel()
    const speech = new SpeechSynthesisUtterance(text); speech.rate = .84; speech.pitch = .7; speech.volume = .65; speech.lang = 'en-US'; speechSynthesis.speak(speech)
  }
  setMuted(value: boolean) { this.muted = value; if (this.master && this.context) this.master.gain.setTargetAtTime(value ? 0 : .35, this.context.currentTime, .2); if (value && typeof speechSynthesis !== 'undefined') speechSynthesis.cancel() }
  dispose() { if (this.breathTimer) clearInterval(this.breathTimer); if (typeof speechSynthesis !== 'undefined') speechSynthesis.cancel(); void this.context?.close(); this.context = null }
}
export const oceanAudio = new OceanAudio()

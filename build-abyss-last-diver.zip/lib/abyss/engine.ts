export type Vec3 = [number, number, number]
export type Item = 'oxygen' | 'battery' | 'scrap' | 'medkit' | 'cell' | 'beacon' | 'blackbox'
export type Upgrade = 'armor' | 'pressure' | 'speed' | 'tank' | 'efficiency' | 'scanner' | 'light'
export type Panel = 'none' | 'inventory' | 'database' | 'missions' | 'pause' | 'core' | 'log'
export type Mode = 'menu' | 'intro' | 'playing' | 'ending'
export type ObjectKind = 'relay' | 'beacon' | 'station' | 'blackbox' | 'gate' | 'return' | 'supply' | 'log' | 'ruin' | 'archive' | 'core' | 'refill'
export type WorldObject = { id: string; name: string; kind: ObjectKind; pos: Vec3; detail: string; hidden?: boolean }
export type Creature = { id: string; kind: 'mimic' | 'lantern' | 'leviathan'; pos: Vec3; origin: Vec3; state: 'patrolling' | 'stalking' | 'luring' | 'fleeing' | 'hunting'; timer: number; cooldown: number }
export type Discovery = { id: string; name: string; depth: number; threat: string; detail: string }
export type SaveData = { version: 1; zone: number; pos: Vec3; yaw: number; pitch: number; oxygen: number; health: number; suit: number; battery: number; inventory: Record<Item, number>; upgrades: Record<Upgrade, number>; mission: number; collected: string[]; discoveries: Discovery[]; logs: number[]; seconds: number; flashlight: boolean; destroyed: string[] }
export const ZONES = [
  { name: 'Surface Wreck', code: 'SECTOR 01', depth: 842, range: '0 — 1,000 M', color: '#092f40', fog: .012, description: 'Sunlight is fading. The emergency ascent pod broke free of the crash. Find a way back down.' },
  { name: 'Dead Station', code: 'SECTOR 02', depth: 2840, range: '1,000 — 4,000 M', color: '#061b29', fog: .018, description: 'Station NEREID is silent. Its emergency systems are still drawing power.' },
  { name: 'Black Trench', code: 'SECTOR 03', depth: 5840, range: '4,000 — 7,000 M', color: '#030e1b', fog: .027, description: 'Strong lateral currents. Do not follow the lights. Something is listening.' },
  { name: 'Ancient Ruins', code: 'SECTOR 04', depth: 8421, range: '7,000 — 10,000 M', color: '#071d27', fog: .021, description: 'The architecture predates us. Your suit records impossible gravitational readings.' },
  { name: 'Abyssal City', code: 'SECTOR 05', depth: 10842, range: '10,000 M+', color: '#041822', fog: .016, description: 'The city is awake. The expedition came here to close a door. They never left.' },
]
export const MISSIONS = [
  { title: 'Restore power', hint: 'Find the amber power relay ahead. Repair it with 2 repair materials.', zone: 0, target: 'relay' },
  { title: 'Find the emergency beacon', hint: 'Recover the beacon beside the wreck. Follow the amber diamond.', zone: 0, target: 'beacon' },
  { title: 'Locate the missing station', hint: 'Take the descent buoy to Dead Station. Enter the open NEREID airlock.', zone: 1, target: 'station' },
  { title: 'Recover the black box', hint: 'Search the station corridor for the expedition recorder.', zone: 1, target: 'blackbox' },
  { title: 'Investigate the ancient ruins', hint: 'Cross Black Trench. Scan and access the monolith in Ancient Ruins.', zone: 3, target: 'ruin' },
  { title: 'Reach the Abyssal City', hint: 'Follow the descent buoy beyond the ruins.', zone: 4, target: 'archive' },
  { title: 'Uncover the expedition’s fate', hint: 'Access the expedition archive in the city.', zone: 4, target: 'archive' },
  { title: 'Decide the fate of the abyss', hint: 'Reach the central energy core. Your choice cannot be undone.', zone: 4, target: 'core' },
]
export const LOGS = [
  { title: '01 / A second descent', text: 'DR. ELENA VOSS — 17 NOV 2042\n\nThe emergency pod reached 842 meters before its ballast failed. If anyone finds this: our wreck is not the first. The structure below has been transmitting our own voices for sixty years. We only arrived yesterday.' },
  { title: '02 / Voices in the walls', text: 'ENGINEER MIN PARK — 19 NOV 2042\n\nNEREID is empty, but I can hear the crew through the bulkhead. It uses our radio frequencies. It only moves when I look away. Kill the beam. Swim slowly. Never answer a voice that knows your name.' },
  { title: '03 / The living lock', text: 'BIOLOGIST ADA OKONKWO — 21 NOV 2042\n\nThe leviathan is not a predator. It is a guardian. Noise and concentrated light provoke it. Small creatures scatter under a scanner pulse. The big one does not. The rocks are your only shelter.' },
  { title: '04 / Not a weapon', text: 'DR. ELENA VOSS — 24 NOV 2042\n\nThe city is a containment system. The expedition fused their neural patterns into its archive to keep it closed. Destroying it will free their minds, but erase every trace of them. Activating it will open the door.' },
  { title: '05 / A different way home', text: 'TRANSMISSION WITHOUT A TIMESTAMP\n\nFive records. Five fragments of a human signature. Together, they form a command the city cannot refuse: release the keepers, preserve the lock. If you have all five, synchronize with the core. Bring us home.' },
]
export const ENDINGS = {
  escape: { number: '01', title: 'The surface remembers.', label: 'ESCAPE THE ABYSS', text: 'Your beacon pierces the static. An ascent capsule carries you toward the light. Below you, the city continues to hum. You survived. But the voices follow you home.' },
  destroy: { number: '02', title: 'Let the silence return.', label: 'SEVER THE CONNECTION', text: 'You overload the ancient system. The expedition’s captive minds dissolve into a final chorus of thanks. The city collapses, and its last reserve of energy launches you toward the surface.' },
  activate: { number: '03', title: 'We were never alone.', label: 'AWAKEN THE CITY', text: 'You place your hand against the core. Eleven thousand meters above, the Pacific begins to glow. The structure was not a city. It was a door. And you have opened it.' },
  trapped: { number: '04', title: 'One more voice.', label: 'REMAIN IN THE ABYSS', text: 'The water settles. The light fades. Your last transmission becomes part of the signal. Years from now, another diver will hear your voice asking for help.' },
  secret: { number: '05', title: 'No one left behind.', label: 'THE FIFTH SIGNAL · SECRET ENDING', text: 'Five fragments become a single human command. The city releases the expedition, preserving its ancient seal. A column of light carries every lost consciousness upward. For the first time, the abyss is quiet.' },
}
export type Ending = keyof typeof ENDINGS
export const UPGRADE_INFO: Record<Upgrade, { name: string; detail: string }> = {
  armor: { name: 'Reinforced armor', detail: 'Reduces creature damage by 20% per level.' },
  pressure: { name: 'Pressure seals', detail: 'Reduces deep-water suit wear by 30% per level.' },
  speed: { name: 'Hydro thrusters', detail: 'Increases swimming speed by 15% per level.' },
  tank: { name: 'Oxygen capacity', detail: 'Adds 25 oxygen capacity and refills the difference.' },
  efficiency: { name: 'Closed-loop rebreather', detail: 'Reduces oxygen consumption by 18% per level.' },
  scanner: { name: 'Spectral scanner', detail: 'Increases range; level 1 identifies lifeforms, level 2 reveals hidden logs.' },
  light: { name: 'Photon efficiency', detail: 'Stronger beam, 25% less battery drain per level.' },
}
const initial = (): SaveData => ({ version: 1, zone: 0, pos: [0, 5, 8], yaw: 0, pitch: 0, oxygen: 100, health: 100, suit: 100, battery: 100, inventory: { oxygen: 2, battery: 2, scrap: 6, medkit: 2, cell: 4, beacon: 0, blackbox: 0 }, upgrades: { armor: 0, pressure: 0, speed: 0, tank: 0, efficiency: 0, scanner: 0, light: 0 }, mission: 0, collected: [], discoveries: [], logs: [], seconds: 0, flashlight: true, destroyed: [] })
export const distance = (a: Vec3, b: Vec3) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2])
export function objectsFor(zone: number): WorldObject[] {
  const o = (id: string, name: string, kind: ObjectKind, pos: Vec3, detail: string, hidden = false): WorldObject => ({ id: `${zone}-${id}`, name, kind, pos, detail, hidden })
  const objects: WorldObject[] = [
    o('cache-a', 'Emergency supply cache', 'supply', [-9, 4, -8], 'Sealed supplies: oxygen, battery, medical kit, 3 repair materials and 2 energy cells.'),
    o('cache-b', 'Expedition supply cache', 'supply', [13, 4, -37], 'Sealed supplies: oxygen, battery, medical kit, 3 repair materials and 2 energy cells.'),
    o('log', LOGS[zone].title, 'log', [-17, 4, -28], LOGS[zone].text, zone > 1),
    o('refill', 'Life-support station', 'refill', [-6, 4, -17], 'Self-powered oxygen condenser. Restores oxygen and suit battery. Reusable.'),
  ]
  if (zone < 4) objects.push(o('gate', 'Descent buoy', 'gate', [0, 6, -58], `Travel to ${ZONES[zone + 1].name}. Your progress will be saved.`))
  if (zone > 0) objects.push(o('return', 'Ascent buoy', 'return', [0, 5, 15], `Return to ${ZONES[zone - 1].name}.`))
  if (zone === 0) objects.push(o('relay', 'Auxiliary power relay', 'relay', [0, 4, -13], 'Damaged emergency circuit. Requires 2 repair materials.'), o('beacon', 'Emergency beacon', 'beacon', [9, 4, -30], 'A functioning acoustic transponder. Your way home.'))
  if (zone === 1) objects.push(o('station', 'NEREID airlock terminal', 'station', [0, 4, -18], 'Research station NEREID. No living crew detected.'), o('blackbox', 'Expedition black box', 'blackbox', [0, 4, -37], 'Contains the last recorded descent and access credentials to the ancient archive.'))
  if (zone === 3) objects.push(o('ruin', 'Unknown monolith', 'ruin', [0, 5, -29], 'Artificial structure. Age: 2.6 million years. Scan before interfacing.'))
  if (zone === 4) objects.push(o('archive', 'Expedition neural archive', 'archive', [-8, 4, -22], 'The crew uploaded their consciousness to maintain the containment field. They are still here.'), o('core', 'Central energy core', 'core', [0, 6, -43], 'Containment control. Five human signatures can release the keepers without opening the seal.'))
  return objects
}
export class AbyssEngine {
  data = initial()
  mode: Mode = 'menu'
  panel: Panel = 'none'
  ending: Ending = 'trapped'
  creatures: Creature[] = []
  keys = new Set<string>()
  stick = { x: 0, y: 0, vertical: 0, fast: false }
  nearest: WorldObject | null = null
  scanTime = 0
  scanCooldown = 0
  message = ''
  messageUntil = 0
  radio = ''
  radioUntil = 0
  logText = ''
  logTitle = ''
  danger = 0
  hidden = false
  pulse = 0
  lastSave = ''
  revision = 0
  listeners = new Set<() => void>()
  checkpoint = initial()
  audioEvent: ((kind: string, text?: string) => void) | null = null
  private updateAccumulator = 0
  subscribe = (callback: () => void) => { this.listeners.add(callback); return () => { this.listeners.delete(callback) } }
  getSnapshot = () => this.revision
  emit = () => { this.revision++; this.listeners.forEach(fn => fn()) }
  get maxOxygen() { return 100 + this.data.upgrades.tank * 25 }
  get depth() { return Math.round(ZONES[this.data.zone].depth + (5 - this.data.pos[1]) * 8) }
  get target(): WorldObject | undefined {
    const m = MISSIONS[Math.min(this.data.mission, 7)]
    const objects = objectsFor(this.data.zone)
    if (this.data.zone < m.zone) return objects.find(o => o.kind === 'gate')
    if (this.data.zone > m.zone) return objects.find(o => o.kind === 'return')
    return objects.find(o => o.kind === m.target)
  }
  get activeObjects() { return objectsFor(this.data.zone).filter(o => !this.data.collected.includes(o.id) && !this.data.destroyed.includes(o.id)) }
  notify(text: string) { this.message = text; this.messageUntil = this.data.seconds + 5; this.emit() }
  say(text: string) { this.radio = text; this.radioUntil = this.data.seconds + 7; this.audioEvent?.('radio', text); this.emit() }
  newGame(intro = true) {
    this.data = initial(); this.mode = intro ? 'intro' : 'playing'; this.panel = 'none'; this.keys.clear(); this.message = ''; this.radio = ''; this.nearest = null; this.danger = 0
    this.loadCreatures(); this.checkpoint = structuredClone(this.data); this.emit()
  }
  begin() { this.mode = 'playing'; this.say('Emergency pod separated. Depth: 842 meters. Restore the relay, then retrace the descent.'); this.save(true); this.emit() }
  loadCreatures() {
    const zone = this.data.zone
    const make = (kind: Creature['kind'], p: Vec3): Creature => ({ id: `${zone}-${kind}`, kind, pos: [...p], origin: [...p], state: kind === 'lantern' ? 'luring' : 'patrolling', timer: 0, cooldown: 0 })
    this.creatures = [make('lantern', [19, 9, -27]), make('leviathan', [45, 20, -66])]
    if (zone > 0) this.creatures.push(make('mimic', [-23, 5, -40]))
  }
  look(dx: number, dy: number) {
    if (this.mode !== 'playing' || this.panel !== 'none') return
    this.data.yaw -= dx * .0025; this.data.pitch = Math.max(-1.35, Math.min(1.35, this.data.pitch - dy * .0025))
  }
  setPanel(panel: Panel) { this.panel = this.panel === panel ? 'none' : panel; this.keys.clear(); this.stick = { x: 0, y: 0, vertical: 0, fast: false }; this.emit() }
  toggleLight() { if (this.mode === 'playing') { this.data.flashlight = !this.data.flashlight; this.audioEvent?.('click'); this.emit() } }
  tick(delta: number) {
    if (this.mode !== 'playing' || this.panel !== 'none') return
    const dt = Math.min(delta, .1), d = this.data
    d.seconds += dt
    const fast = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') || this.stick.fast
    let forward = Number(this.keys.has('KeyW') || this.keys.has('ArrowUp')) - Number(this.keys.has('KeyS') || this.keys.has('ArrowDown')) - this.stick.y
    let right = Number(this.keys.has('KeyD') || this.keys.has('ArrowRight')) - Number(this.keys.has('KeyA') || this.keys.has('ArrowLeft')) + this.stick.x
    let vertical = Number(this.keys.has('Space')) - Number(this.keys.has('ControlLeft') || this.keys.has('ControlRight') || this.keys.has('KeyC')) + this.stick.vertical
    const length = Math.max(1, Math.hypot(forward, right, vertical)); forward /= length; right /= length; vertical /= length
    const moving = Math.abs(forward) + Math.abs(right) + Math.abs(vertical) > .05
    const speed = (fast ? 10 : 5.3) * (1 + d.upgrades.speed * .15) * dt
    const next: Vec3 = [d.pos[0] + (-Math.sin(d.yaw) * forward * Math.cos(d.pitch) + Math.cos(d.yaw) * right) * speed, d.pos[1] + (vertical + Math.sin(d.pitch) * forward) * speed, d.pos[2] + (-Math.cos(d.yaw) * forward * Math.cos(d.pitch) - Math.sin(d.yaw) * right) * speed]
    if (d.zone === 2) next[0] += Math.sin(d.seconds * .2) * .65 * dt
    if (d.zone === 3) next[1] += Math.sin(d.seconds * .7) * .25 * dt
    next[0] = Math.max(-75, Math.min(75, next[0])); next[1] = Math.max(2.4, Math.min(38, next[1])); next[2] = Math.max(-85, Math.min(26, next[2]))
    // Station walls leave an open, traversable central corridor.
    if (d.zone === 1 && next[2] < -15 && next[2] > -43 && next[1] < 10 && Math.abs(next[0]) > 4.3 && Math.abs(next[0]) < 6.8) next[0] = d.pos[0]
    d.pos = next
    d.oxygen = Math.max(0, d.oxygen - dt * .19 * (fast && moving ? 2.1 : 1) * (1 - d.upgrades.efficiency * .18))
    if (d.flashlight) d.battery = Math.max(0, d.battery - dt * .12 * (1 - d.upgrades.light * .25))
    if (d.battery <= 0) d.flashlight = false
    if (d.zone >= 2) d.suit = Math.max(0, d.suit - dt * .018 * (d.zone - 1) * (1 - d.upgrades.pressure * .3))
    if (d.oxygen === 0) d.health -= dt * 4
    if (d.suit <= 0) d.health -= dt * 2
    this.hidden = !d.flashlight && !fast && d.pos[1] < 7
    this.danger = 0
    for (const c of this.creatures) {
      c.timer += dt; c.cooldown = Math.max(0, c.cooldown - dt)
      const dist = distance(c.pos, d.pos)
      let goal: Vec3 = [...c.origin], velocity = 2
      if (c.kind === 'lantern') {
        if (c.state === 'fleeing' && c.timer < 9) { goal = [c.pos[0] + (c.pos[0] - d.pos[0]), c.pos[1] + 4, c.pos[2] - 12]; velocity = 7 }
        else { c.state = 'luring'; goal = [c.origin[0] + Math.sin(c.timer * .3) * 7, 7 + Math.sin(c.timer * .5) * 3, c.origin[2] - Math.cos(c.timer * .2) * 10] }
        if (dist < 5 && c.state !== 'fleeing') this.hurt(c, 6, 'Electrical discharge. Do not follow the light.')
      } else if (c.kind === 'mimic') {
        const towardX = c.pos[0] - d.pos[0], towardZ = c.pos[2] - d.pos[2]
        const facing = (-Math.sin(d.yaw) * towardX - Math.cos(d.yaw) * towardZ) / Math.max(1, dist)
        if (dist < 37 && facing < .6) { c.state = 'stalking'; goal = d.pos; velocity = 2.4 }
        else { c.state = 'patrolling'; goal = [c.origin[0] + Math.sin(c.timer * .13) * 9, 5, c.origin[2] + Math.cos(c.timer * .16) * 6]; velocity = .8 }
        if (dist < 25 && Math.floor(c.timer / 23) !== Math.floor((c.timer - dt) / 23)) this.say('…diver… over here. I can see your light. Don’t turn around…')
        if (dist < 3) this.hurt(c, 12, 'Mimic contact. Face it and back away.')
      } else {
        const detected = !this.hidden && ((fast && moving && dist < 52) || (d.flashlight && dist < 34))
        if (detected || (c.state === 'hunting' && !this.hidden && dist < 48)) { c.state = 'hunting'; goal = d.pos; velocity = 6.3; this.danger = 1 }
        else { c.state = 'patrolling'; goal = [Math.sin(c.timer * .06) * 45, 17 + Math.sin(c.timer * .08) * 8, -42 + Math.cos(c.timer * .06) * 33]; velocity = 3.2 }
        if (dist < 16) this.danger = Math.max(this.danger, .5)
        if (dist < 8) this.hurt(c, 24, 'Leviathan impact. Lights off. Stay low. Stop sprinting.')
        if (c.state === 'hunting') for (const o of this.activeObjects) if (o.kind === 'supply' && distance(c.pos, o.pos) < 7) { d.destroyed.push(o.id); this.notify('The leviathan crushed a supply cache.'); this.audioEvent?.('impact') }
      }
      const gap = distance(c.pos, goal)
      if (gap > .1) for (let i = 0; i < 3; i++) c.pos[i] += (goal[i] - c.pos[i]) / gap * Math.min(gap, velocity * dt)
    }
    this.scanTime = Math.max(0, this.scanTime - dt); this.scanCooldown = Math.max(0, this.scanCooldown - dt)
    this.pulse = Math.max(0, this.pulse - dt)
    this.nearest = this.activeObjects.filter(o => distance(o.pos, d.pos) < 7).sort((a, b) => distance(a.pos, d.pos) - distance(b.pos, d.pos))[0] ?? null
    if (d.health <= 0) { d.health = 0; this.finish('trapped') }
    this.updateAccumulator += dt
    if (this.updateAccumulator > .1) { this.updateAccumulator = 0; this.emit() }
  }
  hurt(c: Creature, amount: number, message: string) {
    if (c.cooldown > 0) return
    c.cooldown = 5; this.data.health = Math.max(0, this.data.health - amount * (1 - this.data.upgrades.armor * .2)); this.data.suit = Math.max(0, this.data.suit - amount * .4); this.pulse = 1; this.notify(message); this.audioEvent?.('impact')
  }
  scan() {
    if (this.mode !== 'playing' || this.panel !== 'none') return
    if (this.scanCooldown > 0) return this.notify('Scanner recharging.')
    if (this.data.battery < 4) return this.notify('Insufficient battery. Replace a battery in inventory.')
    this.data.battery -= 4; this.scanTime = 2.5; this.scanCooldown = 4; this.audioEvent?.('scan')
    const range = 25 + this.data.upgrades.scanner * 15
    let found = 0
    for (const o of this.activeObjects) if (distance(o.pos, this.data.pos) < range && (!o.hidden || this.data.upgrades.scanner >= 2 || distance(o.pos, this.data.pos) < 10)) {
      if (!this.data.discoveries.some(d => d.id === o.id)) { this.data.discoveries.push({ id: o.id, name: o.name, depth: this.depth, threat: 'NONE', detail: o.detail }); found++ }
    }
    for (const c of this.creatures) if (distance(c.pos, this.data.pos) < range) {
      if (c.kind === 'lantern') { c.state = 'fleeing'; c.timer = 0 }
      const info = { mimic: 'Copies radio signals. Approaches when outside your field of view.', lantern: 'Bioluminescent lure. Delivers an electrical shock. Repelled by scanning.', leviathan: 'Guardian megafauna. Detects fast movement and powerful light. Hide low with lights off. Cannot be killed.' }
      const name = this.data.upgrades.scanner ? `The ${c.kind}` : `Unknown organism / ${c.kind}`
      const record = { id: c.id, name, depth: this.depth, threat: c.kind === 'leviathan' ? 'EXTREME' : 'HIGH', detail: this.data.upgrades.scanner ? info[c.kind] : 'BIOLOGICAL SIGNATURE: UNIDENTIFIED. Upgrade your scanner to identify behavior.' }
      const idx = this.data.discoveries.findIndex(d => d.id === c.id)
      if (idx < 0) { this.data.discoveries.push(record); found++ } else this.data.discoveries[idx] = record
    }
    this.notify(`Scan complete. ${found} new records. Open the database to review.`)
  }
  complete() { this.data.mission = Math.min(8, this.data.mission + 1); this.audioEvent?.('complete'); this.notify('Objective complete. New coordinates received.'); this.save(true) }
  interact() {
    if (this.mode !== 'playing' || this.panel !== 'none') return
    const o = this.nearest
    if (!o || distance(o.pos, this.data.pos) >= 7) return this.notify('Move within 7 meters of an object to interact.')
    const d = this.data
    if (o.kind === 'supply') { d.inventory.oxygen++; d.inventory.battery++; d.inventory.medkit++; d.inventory.scrap += 3; d.inventory.cell += 2; d.collected.push(o.id); this.notify('Supplies recovered: O₂, battery, medkit, 3 materials, 2 cells.') }
    if (o.kind === 'refill') { d.oxygen = this.maxOxygen; d.battery = 100; this.notify('Life support connected. Oxygen and battery fully restored.'); this.audioEvent?.('complete') }
    if (o.kind === 'relay') {
      if (d.mission > 0) return this.notify('Auxiliary power online.')
      if (d.inventory.scrap < 2) return this.notify('Requires 2 repair materials. Search a supply cache.')
      d.inventory.scrap -= 2; this.complete(); this.say('Power restored. Emergency beacon signal located beside the wreck.')
    }
    if (o.kind === 'beacon') {
      if (d.mission < 1) return this.notify('Restore the power relay first.')
      d.inventory.beacon = 1; d.collected.push(o.id); if (d.mission === 1) this.complete(); this.say('Beacon recovered. Descent buoy is online. Return to NEREID.')
    }
    if (o.kind === 'station') { if (d.mission === 2) this.complete(); this.say('NEREID station. Crew count: zero. Neural signatures: seven. Locate the black box.') }
    if (o.kind === 'blackbox') {
      if (d.mission < 3) return this.notify('Access the airlock terminal first.')
      d.inventory.blackbox = 1; d.collected.push(o.id); if (d.mission === 3) this.complete(); this.say('Black box decrypted: “We did not discover it. It called us.” Continue through Black Trench.')
    }
    if (o.kind === 'log') { if (!d.logs.includes(d.zone)) d.logs.push(d.zone); d.collected.push(o.id); this.logTitle = LOGS[d.zone].title; this.logText = LOGS[d.zone].text; this.setPanel('log'); this.audioEvent?.('radio', LOGS[d.zone].text.split('\n\n')[1]) }
    if (o.kind === 'ruin') {
      if (!d.discoveries.some(r => r.id === o.id)) return this.notify('Unknown interface. Scan the monolith with Q first.')
      if (d.mission === 4) this.complete(); this.say('The symbols are a warning. The city is a lock, not a home. Its keepers are human.')
    }
    if (o.kind === 'archive') { if (d.mission < 6) return this.notify('Complete the earlier expedition objectives first.'); if (d.mission === 6) this.complete(); this.logTitle = 'The last expedition'; this.logText = o.detail + '\n\nSeven researchers. Seven keepers. The core can free them, or consume you. Recover all five hidden research logs to find another way.'; this.setPanel('log') }
    if (o.kind === 'core') { if (d.mission < 7) return this.notify('Access the expedition archive first.'); this.setPanel('core') }
    if (o.kind === 'gate') {
      if (d.zone === 0 && d.mission < 2) return this.notify('Restore power and recover the beacon before descending.')
      if (d.zone === 1 && d.mission < 4) return this.notify('Recover the station black box before descending.')
      if (d.zone === 3 && d.mission < 5) return this.notify('Investigate the monolith before descending.')
      this.travel(d.zone + 1); return
    }
    if (o.kind === 'return') { this.travel(d.zone - 1); return }
    this.nearest = null; this.save(false, true); this.emit()
  }
  travel(zone: number) {
    if (zone < 0 || zone > 4) return
    const returning = zone < this.data.zone
    this.data.zone = zone; this.data.pos = returning ? [0, 5, -48] : [0, 5, 8]; this.data.yaw = returning ? Math.PI : 0; this.data.pitch = 0
    this.loadCreatures(); this.nearest = null; this.scanTime = 0; this.danger = 0
    if (zone === 4 && this.data.mission === 5) this.complete()
    this.say(ZONES[zone].description); this.save(true); this.emit()
  }
  useItem(item: Item) {
    const d = this.data
    if (d.inventory[item] <= 0) return this.notify('No supplies remaining. Search for a cache.')
    if (item === 'oxygen') { d.oxygen = Math.min(this.maxOxygen, d.oxygen + 70); this.notify('Oxygen tank connected. +70 O₂.') }
    else if (item === 'battery') { d.battery = Math.min(100, d.battery + 75); this.notify('Battery replaced. +75 charge.') }
    else if (item === 'medkit') { d.health = Math.min(100, d.health + 55); this.notify('Medical seal applied. +55 health.') }
    else if (item === 'scrap') { d.suit = Math.min(100, d.suit + 35); this.notify('Repair tool engaged. +35 suit integrity.') }
    else if (item === 'beacon') { if (d.zone !== 4 || d.mission < 7) return this.notify('Signal blocked. Reach the city core to establish an escape route.'); this.finish('escape'); return }
    else return
    d.inventory[item]--; this.audioEvent?.('complete'); this.emit()
  }
  upgrade(key: Upgrade) {
    const d = this.data, level = d.upgrades[key], cost = 2 + level
    if (level >= 3) return this.notify('Maximum upgrade level reached.')
    if (d.inventory.scrap < cost || d.inventory.cell < 1) return this.notify(`Upgrade requires ${cost} repair materials and 1 energy cell.`)
    d.inventory.scrap -= cost; d.inventory.cell--; d.upgrades[key]++
    if (key === 'tank') d.oxygen += 25
    this.notify(`${UPGRADE_INFO[key].name} upgraded to level ${level + 1}.`); this.audioEvent?.('complete'); this.emit()
  }
  harpoon() {
    if (this.mode !== 'playing' || this.panel !== 'none') return
    if (this.data.inventory.scrap < 1) return this.notify('Harpoon requires 1 repair material.')
    this.data.inventory.scrap--; this.audioEvent?.('impact')
    const creature = this.creatures.filter(c => distance(c.pos, this.data.pos) < 22).sort((a,b) => distance(a.pos,this.data.pos)-distance(b.pos,this.data.pos))[0]
    if (!creature) return this.notify('Harpoon discharged. No target in range.')
    if (creature.kind === 'leviathan') { creature.state = 'hunting'; return this.notify('Harpoon ineffective. You have attracted its attention.') }
    creature.pos[0] += 22; creature.pos[2] -= 20; creature.state = 'fleeing'; creature.timer = 0; this.notify('Threat repelled. Keep moving.')
  }
  finish(ending: Ending) {
    if (ending === 'secret' && this.data.logs.length < 5) return
    if (ending !== 'trapped' && this.data.mission < 7) return
    this.ending = ending; this.mode = 'ending'; this.panel = 'none'; this.keys.clear(); this.audioEvent?.('ending'); this.emit()
  }
  save(checkpoint = false, silent = false) {
    if (typeof localStorage === 'undefined') return false
    try { localStorage.setItem('abyss-save-v1', JSON.stringify(this.data)); if (checkpoint) { this.checkpoint = structuredClone(this.data); localStorage.setItem('abyss-checkpoint-v1', JSON.stringify(this.checkpoint)) }; this.lastSave = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); if (!silent) this.notify(checkpoint ? 'Checkpoint synchronized.' : 'Dive progress saved.'); return true } catch { this.notify('Browser storage unavailable. Your progress could not be saved.'); return false }
  }
  load(checkpoint = false) {
    try {
      const raw = localStorage.getItem(checkpoint ? 'abyss-checkpoint-v1' : 'abyss-save-v1'); if (!raw) return false
      const d = JSON.parse(raw) as SaveData
      if (d.version !== 1 || !Number.isInteger(d.zone) || d.zone < 0 || d.zone > 4 || !Array.isArray(d.pos) || d.pos.length !== 3 || !d.pos.every(Number.isFinite) || !Number.isInteger(d.mission) || d.mission < 0 || d.mission > 8) return false
      if (!['oxygen','health','suit','battery','seconds','yaw','pitch'].every(k => Number.isFinite(d[k as keyof SaveData])) || !d.inventory || !d.upgrades || !Object.keys(initial().inventory).every(k => Number.isFinite(d.inventory[k as Item]) && d.inventory[k as Item] >= 0) || !Object.keys(initial().upgrades).every(k => Number.isInteger(d.upgrades[k as Upgrade]) && d.upgrades[k as Upgrade] >= 0 && d.upgrades[k as Upgrade] <= 3) || !Array.isArray(d.collected) || !Array.isArray(d.discoveries) || !Array.isArray(d.logs) || !Array.isArray(d.destroyed)) return false
      this.data = d; this.mode = 'playing'; this.panel = 'none'; this.keys.clear(); this.loadCreatures(); this.nearest = null; this.checkpoint = structuredClone(d); this.notify('Dive restored. Welcome back, diver.'); this.emit(); return true
    } catch { return false }
  }
}
export const game = new AbyssEngine()

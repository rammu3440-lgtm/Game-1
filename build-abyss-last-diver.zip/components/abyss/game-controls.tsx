'use client'

import { useEffect, useRef, useState, type PointerEvent } from 'react'
import { ArrowDown, ArrowUp, Zap } from 'lucide-react'
import { game } from '@/lib/abyss/engine'

export function DesktopControls() {
  useEffect(() => {
    const down = (event: KeyboardEvent) => {
      if (event.isComposing || event.keyCode === 229 || game.mode !== 'playing') return
      if (['Space', 'ControlLeft', 'ControlRight', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(event.code)) event.preventDefault()
      if (event.repeat) return
      if (event.code === 'Escape') game.setPanel('pause')
      if (event.code === 'KeyI') game.setPanel('inventory')
      if (event.code === 'KeyJ') game.setPanel('database')
      if (event.code === 'KeyM') game.setPanel('missions')
      if (game.panel !== 'none') return
      game.keys.add(event.code)
      if (event.code === 'KeyF') game.toggleLight()
      if (event.code === 'KeyQ') game.scan()
      if (event.code === 'KeyE') game.interact()
      if (event.code === 'KeyH') game.harpoon()
    }
    const up = (event: KeyboardEvent) => game.keys.delete(event.code)
    const blur = () => { game.keys.clear(); if (game.mode === 'playing' && game.panel === 'none') game.setPanel('pause') }
    const visibility = () => { if (document.hidden) blur() }
    const move = (event: MouseEvent) => { if (document.pointerLockElement) game.look(event.movementX, event.movementY) }
    window.addEventListener('keydown', down); window.addEventListener('keyup', up); window.addEventListener('blur', blur); document.addEventListener('visibilitychange', visibility); document.addEventListener('mousemove', move)
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); window.removeEventListener('blur', blur); document.removeEventListener('visibilitychange', visibility); document.removeEventListener('mousemove', move) }
  }, [])
  return null
}
export function LookSurface() {
  const previous = useRef<{ x: number; y: number } | null>(null)
  return <div className="look-surface" aria-label="Ocean view. Drag to look around; double click for mouse capture." onPointerDown={e => { if (document.pointerLockElement) return; previous.current = { x: e.clientX, y: e.clientY }; e.currentTarget.setPointerCapture(e.pointerId) }} onPointerMove={e => { if (!previous.current || document.pointerLockElement) return; game.look(e.clientX - previous.current.x, e.clientY - previous.current.y); previous.current = { x: e.clientX, y: e.clientY } }} onPointerUp={() => { previous.current = null }} onPointerCancel={() => { previous.current = null }} onDoubleClick={e => { try { const request = e.currentTarget.requestPointerLock?.(); if (request) void request.catch(() => game.notify('Mouse capture unavailable here. Drag to look around.')) } catch { game.notify('Drag to look around.') } }} />
}
export function TouchControls() {
  const [stick, setStick] = useState({ x: 0, y: 0 })
  const move = (e: PointerEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect(), dx = e.clientX - rect.left - rect.width / 2, dy = e.clientY - rect.top - rect.height / 2, length = Math.max(1, Math.hypot(dx, dy) / 38)
    const x = dx / length, y = dy / length; setStick({ x, y }); game.stick.x = x / 38; game.stick.y = y / 38
  }
  const reset = () => { setStick({ x: 0, y: 0 }); game.stick.x = 0; game.stick.y = 0 }
  return <div className="touch-controls">
    <div className="joystick" role="group" aria-label="Movement joystick" onPointerDown={e => { e.currentTarget.setPointerCapture(e.pointerId); move(e) }} onPointerMove={e => { if (e.currentTarget.hasPointerCapture(e.pointerId)) move(e) }} onPointerUp={reset} onPointerCancel={reset}><span className="joystick-axis" /><span className="joystick-knob" style={{ transform: `translate(${stick.x}px, ${stick.y}px)` }} /><small>MOVE</small></div>
    <div className="vertical-controls">{[{ label: 'Swim up', value: 1, Icon: ArrowUp }, { label: 'Swim down', value: -1, Icon: ArrowDown }].map(({ label, value, Icon }) => <button key={label} aria-label={label} onPointerDown={e => { e.currentTarget.setPointerCapture(e.pointerId); game.stick.vertical = value }} onPointerUp={() => { game.stick.vertical = 0 }} onPointerCancel={() => { game.stick.vertical = 0 }}><Icon size={19} /></button>)}<button aria-label="Fast swim" onPointerDown={e => { e.currentTarget.setPointerCapture(e.pointerId); game.stick.fast = true }} onPointerUp={() => { game.stick.fast = false }} onPointerCancel={() => { game.stick.fast = false }}><Zap size={18} /></button></div>
  </div>
}

'use client'

import dynamic from 'next/dynamic'
import { useEffect, useState, useSyncExternalStore } from 'react'
import { ArrowDown, ArrowRight, AudioLines, Battery, ChevronRight, Compass, Database, Flashlight, Hand, Headphones, HeartPulse, Maximize, Pause, Play, Radio, ScanLine, Settings2, Shield, Volume2, VolumeX, Waves, Wind, Wrench, X } from 'lucide-react'
import { game, ZONES, MISSIONS, ENDINGS, distance } from '@/lib/abyss/engine'
import { oceanAudio } from '@/lib/abyss/audio'
import { DesktopControls, LookSurface, TouchControls } from './game-controls'
import { FieldManual, GamePanels } from './game-panels'
const OceanScene = dynamic(() => import('./ocean-scene'), { ssr: false, loading: () => <div className="world-loading"><span className="loading-ring" /><span>PRESSURIZING SUIT…</span></div> })

function Emblem() { return <span className="emblem"><Waves size={20} strokeWidth={1.5} /></span> }
function MainMenu({ saved, onNew, onContinue, muted, setMuted, lowQuality, setLowQuality }: { saved: boolean; onNew: () => void; onContinue: () => void; muted: boolean; setMuted: (v: boolean) => void; lowQuality: boolean; setLowQuality: (v: boolean) => void }) {
  const [overlay, setOverlay] = useState<'manual' | 'settings' | 'confirm' | null>(null)
  useEffect(() => { const close = (e: KeyboardEvent) => { if (e.key === 'Escape') setOverlay(null) }; window.addEventListener('keydown', close); return () => window.removeEventListener('keydown', close) }, [])
  return <main className="main-menu">
    <div className="key-art" /><div className="menu-shade" /><div className="ocean-dust" aria-hidden="true" /><div className="film-grain" aria-hidden="true" />
    <header className="menu-header"><a className="program-mark" href="/" aria-label="ABYSS home"><Emblem /><span>PELAGIC<span>DEEP SEA EXPLORATION PROGRAM</span></span></a><div className="expedition-coordinates">11° 22′ N &nbsp; 142° 35′ E<span>NORTH PACIFIC OCEAN</span></div><div className="menu-header-actions"><button className="audio-status" onClick={() => { oceanAudio.start(); setMuted(!muted) }}>{muted ? <VolumeX size={15} /> : <AudioLines size={15} />}<span>AUDIO {muted ? 'OFF' : 'ON'}</span></button><button className="icon-button" aria-label="Settings" onClick={() => setOverlay('settings')}><Settings2 size={18} /></button></div></header>
    <div className="menu-body"><section className="menu-hero"><div className="signal-status"><i /><span>CONNECTION LOST</span><span className="signal-line" /><span>EXPEDITION 07</span></div><h1>ABYSS<span>LAST DIVER</span></h1><p className="hero-tagline">Some things were never meant<br />to be found.</p><div className="main-actions"><button className="dive-button" onClick={() => saved ? setOverlay('confirm') : onNew()}><span className="button-index">01</span><span>Begin descent<small>START A NEW EXPEDITION</small></span><ArrowRight size={22} /></button><button className="menu-action" disabled={!saved} onClick={onContinue}><span className="button-index">02</span><span>Continue dive<small>{saved ? 'RESTORE YOUR LAST SIGNAL' : 'NO PREVIOUS SIGNAL FOUND'}</small></span><ChevronRight size={19} /></button><button className="menu-action" onClick={() => setOverlay('manual')}><span className="button-index">03</span><span>Field manual<small>KNOW YOUR EQUIPMENT</small></span><ChevronRight size={19} /></button></div><div className="headphones-note"><Headphones size={15} /><span>Best experienced with headphones. And the lights off.</span></div></section>
    <aside className="wreck-caption"><span className="scene-cross">+</span><div><span className="eyebrow">LAST KNOWN LOCATION</span><h2>Challenger Deep</h2><p>DEPTH <strong>10,842</strong> M <span> / </span> SIGNAL <span className="amber">LOST</span></p></div><span className="caption-line" /></aside></div>
    <footer className="menu-footer"><div className="depth-route"><div className="route-line" />{ZONES.map((z, i) => <div className={`route-stop ${i === 4 ? 'route-unknown' : ''}`} key={z.name}><span className="route-dot" /><span className="route-number">0{i + 1}</span><span className="route-name">{i === 4 ? 'THE UNKNOWN' : z.name.toUpperCase()}</span></div>)}</div><div className="footer-meta"><span><i /> ALL SYSTEMS NOMINAL <span className="meta-slash">/</span> EXO-SUIT MK. IV</span><span>2042 <span className="meta-slash">/</span> A DEEP SEA SURVIVAL EXPERIENCE</span><span>BUILD 1.0 <span className="amber">●</span></span></div></footer>
    {overlay && <div className="panel-backdrop"><section className="game-panel menu-dialog" role="dialog" aria-modal="true" aria-labelledby="menu-dialog-title"><header className="panel-header"><div><span className="eyebrow">EXPEDITION PREPARATION</span><h2 id="menu-dialog-title">{overlay === 'manual' ? 'Field manual' : overlay === 'confirm' ? 'A new descent' : 'Dive settings'}</h2></div><button autoFocus className="icon-button" aria-label="Close dialog" onClick={() => setOverlay(null)}><X size={21} /></button></header><div className="panel-body">{overlay === 'manual' ? <FieldManual /> : overlay === 'confirm' ? <><p className="panel-intro">Starting a new expedition replaces your saved dive once the opening finishes. Your current checkpoint will be overwritten.</p><button className="primary-button" onClick={onNew}>Begin new expedition <ArrowRight size={18} /></button><button className="text-button" onClick={() => setOverlay(null)}>Keep my current dive</button></> : <><p className="panel-intro">A full 3D experience, tuned for the device you have.</p><div className="settings-row"><label>Sound & radio<button onClick={() => { oceanAudio.start(); setMuted(!muted) }}>{muted ? 'MUTED' : 'ENABLED'}</button></label><label>Graphics<button onClick={() => setLowQuality(!lowQuality)}>{lowQuality ? 'PERFORMANCE' : 'HIGH QUALITY'}</button></label></div><p className="muted-note">Performance mode reduces pixel density and disables anti-aliasing. Radio dialogue uses your browser’s available speech voice; all transmissions also have subtitles. Saves stay in this browser.</p></>}</div></section></div>}
  </main>
}
const introLines = [
  { who: 'CONTROL', text: 'Diver, confirm depth.' },
  { who: 'DIVER 07', text: '10,842 meters.' },
  { who: 'CONTROL', text: 'That’s impossible.' },
  { who: 'SIGNAL LOST', text: '…stay with us… diver…' },
  { who: '', text: '' },
]
function Opening() {
  const [step, setStep] = useState(0)
  useEffect(() => { const timers = [3200, 6500, 10100, 12500, 16500].map((ms, i) => setTimeout(() => i === 4 ? game.begin() : setStep(i + 1), ms)); return () => timers.forEach(clearTimeout) }, [])
  useEffect(() => { if (step < 4) oceanAudio.event('radio', introLines[step].text); if (step === 3) oceanAudio.event('impact') }, [step])
  return <div className={`opening opening-step-${step}`}><div className="opening-ocean" />{step >= 3 && <div className="giant-shadow" />}{step < 4 ? <div className="radio-dialogue"><span>{introLines[step].who}</span><p>“{introLines[step].text}”</p><div className="radio-wave"><AudioLines size={35} /></div></div> : <div className="opening-title"><h1>ABYSS</h1><span>LAST DIVER</span></div>}<div className="opening-caption">{step < 3 ? 'PACIFIC OCEAN / NOVEMBER 2042' : step === 3 ? 'HULL FAILURE · EMERGENCY POD EJECTED' : 'SOME THINGS WERE NEVER MEANT TO BE FOUND'}</div><button className="skip-intro" onClick={() => game.begin()}>Skip transmission <ArrowRight size={15} /></button></div>
}
function Meter({ label, value, max = 100, Icon }: { label: string; value: number; max?: number; Icon: typeof Shield }) {
  return <div className={`hud-meter ${value / max < .25 ? 'critical' : ''}`}><Icon size={15} /><div><div className="meter-label"><span>{label}</span><strong>{Math.ceil(value)}<small>{label === 'OXYGEN' ? ' / ' + max : '%'}</small></strong></div><div className="meter-track"><span style={{ width: `${Math.max(0, Math.min(100, value / max * 100))}%` }} /></div></div></div>
}
function HUD() {
  const d = game.data, z = ZONES[d.zone], target = game.target
  const heading = ((-d.yaw * 180 / Math.PI) % 360 + 360) % 360
  const actions = [
    { label: 'Flashlight', key: 'F', Icon: Flashlight, active: d.flashlight, run: () => game.toggleLight() },
    { label: 'Scanner', key: 'Q', Icon: ScanLine, active: game.scanTime > 0, run: () => game.scan() },
    { label: 'Interact', key: 'E', Icon: Hand, active: !!game.nearest, run: () => game.interact() },
    { label: 'Inventory', key: 'I', Icon: Wrench, active: false, run: () => game.setPanel('inventory') },
    { label: 'Database', key: 'J', Icon: Database, active: false, run: () => game.setPanel('database') },
    { label: 'Pause', key: 'ESC', Icon: Pause, active: false, run: () => game.setPanel('pause') },
  ]
  return <div className="hud">
    <header className="hud-header"><div className="hud-brand"><Emblem /><div>ABYSS<span>LAST DIVER</span></div></div><div className="compass"><span>NW</span><i /><span>N</span><i /><strong>{Math.round(heading).toString().padStart(3, '0')}°</strong><i /><span>E</span><i /><span>SE</span><b>▼</b></div><div className="depth-display"><span>DEPTH / METERS</span><strong>{game.depth.toLocaleString()}<small> M</small></strong><span><i /> {z.code} / {z.name.toUpperCase()}</span></div></header>
    <button className="active-objective" onClick={() => game.setPanel('missions')}><span className="eyebrow"><i /> ACTIVE OBJECTIVE <ChevronRight size={12} /></span><strong>{MISSIONS[Math.min(d.mission, 7)].title}</strong><small>{target ? `${target.name} · ${Math.round(distance(d.pos, target.pos))} m` : 'Awaiting coordinates'}</small></button>
    {game.danger > 0 && <div className="threat-warning"><Radio size={15} /> {game.danger === 1 ? 'LARGE SIGNATURE APPROACHING · LIGHTS OFF · STAY LOW' : 'MASSIVE BIOLOGICAL SIGNATURE NEARBY'}</div>}
    {target && <div id="projected-objective" className="world-label projected-objective"><span>◇</span>{target.name}<small>{Math.round(distance(d.pos, target.pos))} m</small></div>}
    <div className="reticle"><span /><i /><span /></div>
    {game.scanTime > 0 && <div className="scan-overlay"><span>SONAR PULSE</span><p>BIOLOGICAL & STRUCTURAL ANALYSIS</p></div>}
    {game.nearest && <div className="interaction-prompt"><span>{game.nearest.name}</span><button onClick={() => game.interact()}><kbd>E</kbd> {game.nearest.kind === 'gate' ? 'DESCEND' : game.nearest.kind === 'return' ? 'ASCEND' : game.nearest.kind === 'refill' ? 'REPLENISH' : 'INTERACT'}<ChevronRight size={15} /></button></div>}
    {game.radioUntil > d.seconds && game.radio && <div className="radio-subtitle"><AudioLines size={21} /><div><span>COMMS / DAMAGED SIGNAL</span><p>{game.radio}</p></div></div>}
    <div className="vitals"><div className="vitals-title"><span>EXO-SUIT MK. IV</span><span className={game.hidden ? 'safe-text' : ''}>{game.hidden ? 'CONCEALED' : 'LIFE SUPPORT'}</span></div><Meter label="OXYGEN" value={d.oxygen} max={game.maxOxygen} Icon={Wind} /><div className="small-vitals"><Meter label="HEALTH" value={d.health} Icon={HeartPulse} /><Meter label="SUIT" value={d.suit} Icon={Shield} /><Meter label="BATTERY" value={d.battery} Icon={Battery} /></div></div>
    <nav className="toolbelt" aria-label="Diver tools">{actions.map(({ label, key, Icon, active, run }) => <button key={key} aria-label={label} title={`${label} (${key})`} className={active ? 'active' : ''} onClick={run}><kbd>{key}</kbd><Icon size={19} /><span>{label}</span></button>)}</nav>
    <div className="sonar-block"><div className="sonar"><div className="sonar-sweep" /><span className="sonar-origin" />{game.creatures.map(c => { const x = (c.pos[0] - d.pos[0]) * .6, y = (c.pos[2] - d.pos[2]) * .6; return Math.hypot(x, y) < 48 && <i key={c.id} className={c.kind === 'leviathan' ? 'large-blip' : ''} style={{ transform: `translate(${x}px, ${y}px)` }} /> })}{target && <b style={{ transform: `translate(${Math.max(-35,Math.min(35,(target.pos[0]-d.pos[0])*.6))}px, ${Math.max(-35,Math.min(35,(target.pos[2]-d.pos[2])*.6))}px)` }} />}</div><span>PASSIVE SONAR <i /> ONLINE</span></div>
    <div className="desktop-hint">WASD MOVE <span>·</span> DRAG TO LOOK <span>·</span> SPACE / CTRL ASCEND / DESCEND</div><TouchControls />
  </div>
}
export default function AbyssGame() {
  useSyncExternalStore(game.subscribe, game.getSnapshot, game.getSnapshot)
  const [saved, setSaved] = useState(false), [muted, setMutedState] = useState(false), [lowQuality, setLowQuality] = useState(false)
  useEffect(() => { try { setSaved(!!localStorage.getItem('abyss-save-v1')) } catch { setSaved(false) }; setLowQuality(window.innerWidth < 768); game.audioEvent = oceanAudio.event; return () => { game.audioEvent = null; oceanAudio.dispose() } }, [])
  const setMuted = (value: boolean) => { setMutedState(value); oceanAudio.setMuted(value) }
  const start = () => { oceanAudio.start(); game.newGame() }
  const continueDive = () => { oceanAudio.start(); if (!game.load()) { setSaved(false); game.notify('Saved data could not be restored. Start a new descent.') } }
  const menu = () => { game.save(false, true); game.mode = 'menu'; game.panel = 'none'; game.keys.clear(); setSaved(true); game.emit(); if (document.pointerLockElement) document.exitPointerLock() }
  const fullscreen = () => { if (document.fullscreenElement) void document.exitFullscreen(); else void document.documentElement.requestFullscreen?.().catch(() => game.notify('Full screen is unavailable in this browser view.')) }
  return <div className="abyss-app" data-mode={game.mode} data-zone={game.data.zone} data-mission={game.data.mission} data-x={game.data.pos[0].toFixed(1)} data-z={game.data.pos[2].toFixed(1)}>
    <DesktopControls />
    {game.mode === 'menu' && <MainMenu saved={saved} onNew={start} onContinue={continueDive} muted={muted} setMuted={setMuted} lowQuality={lowQuality} setLowQuality={setLowQuality} />}
    {game.mode === 'intro' && <Opening />}
    {(game.mode === 'playing' || game.mode === 'ending') && <><OceanScene lowQuality={lowQuality} /><div className="dive-vignette" /><div className="damage-overlay" style={{ opacity: game.pulse * .45 }} />{game.mode === 'playing' && <><LookSurface /><HUD /><div className="utility-actions"><button aria-label={muted ? 'Enable audio' : 'Mute audio'} onClick={() => setMuted(!muted)}>{muted ? <VolumeX size={16} /> : <Volume2 size={16} />}</button><button aria-label="Toggle fullscreen" onClick={fullscreen}><Maximize size={15} /></button></div><GamePanels onMenu={menu} lowQuality={lowQuality} setLowQuality={setLowQuality} muted={muted} setMuted={setMuted} /></>}{game.mode === 'ending' && <div className="ending-screen"><span className="eyebrow">TRANSMISSION ENDED / ENDING {ENDINGS[game.ending].number} OF 05</span><div className="ending-icon"><Compass size={43} strokeWidth={1} /></div><span className="ending-label">{ENDINGS[game.ending].label}</span><h1>{ENDINGS[game.ending].title}</h1><p>{ENDINGS[game.ending].text}</p><div className="ending-stats"><span>{game.data.discoveries.length} DISCOVERIES</span><span>{game.data.logs.length}/5 RESEARCH LOGS</span><span>{Math.floor(game.data.seconds / 60)} MINUTES</span></div><div className="ending-actions"><button className="primary-button" onClick={() => { if (!game.load(true)) game.newGame(false) }}>Restart checkpoint <ArrowRight size={17} /></button><button className="text-button" onClick={menu}>Return to main menu</button></div></div>}</>}
    {game.message && game.messageUntil > game.data.seconds && game.mode !== 'intro' && <div className="toast" role="status"><span className="toast-dot" />{game.message}</div>}
  </div>
}

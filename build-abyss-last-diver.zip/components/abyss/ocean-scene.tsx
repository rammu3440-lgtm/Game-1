'use client'

import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Component, useMemo, useRef, useSyncExternalStore, type ReactNode } from 'react'
import * as THREE from 'three'
import { game, ZONES, type Creature, type WorldObject } from '@/lib/abyss/engine'

const rand = (i: number) => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x) }
function Terrain() {
  const geometry = useMemo(() => {
    const g = new THREE.PlaneGeometry(230, 230, 64, 64); g.rotateX(-Math.PI / 2)
    const positions = g.attributes.position
    for (let i = 0; i < positions.count; i++) { const x = positions.getX(i), z = positions.getZ(i); positions.setY(i, Math.sin(x * .12) * Math.cos(z * .1) * 1.2 + Math.sin(x * .36 + z * .24) * .35 - 1.6) }
    g.computeVertexNormals(); return g
  }, [])
  return <mesh geometry={geometry} position={[0, 0, -30]}><meshStandardMaterial color="#18303b" roughness={.95} metalness={.22} /></mesh>
}
function Rocks({ zone }: { zone: number }) {
  const ref = useRef<THREE.InstancedMesh>(null)
  const matrices = useMemo(() => Array.from({ length: 100 }, (_, i) => {
    const dummy = new THREE.Object3D(); const x = (rand(i + zone * 40) - .5) * 180
    dummy.position.set(Math.abs(x) < 10 ? x + 20 : x, -1, rand(i + 700) * -150 + 28)
    const s = 2 + rand(i + 91) * 9; dummy.scale.set(s, s * (zone === 2 ? 2.7 : .6 + rand(i + 333)), s * .9); dummy.rotation.set(rand(i) * .4, rand(i + 8) * 5, rand(i + 9) * .4); dummy.updateMatrix(); return dummy.matrix
  }), [zone])
  return <instancedMesh ref={ref} args={[undefined, undefined, 100]} onUpdate={m => { matrices.forEach((matrix, i) => m.setMatrixAt(i, matrix)); m.instanceMatrix.needsUpdate = true }}><dodecahedronGeometry args={[1, 1]} /><meshStandardMaterial color={zone > 2 ? '#183840' : '#1c3039'} roughness={.9} /></instancedMesh>
}
function MarineSnow() {
  const ref = useRef<THREE.Points>(null)
  const positions = useMemo(() => new Float32Array(Array.from({ length: 650 * 3 }, (_, i) => (rand(i + 40) - .5) * (i % 3 === 1 ? 65 : 150))), [])
  useFrame((_, dt) => { if (ref.current) { ref.current.rotation.y += dt * .003; ref.current.position.set(game.data.pos[0] * .3, 15, game.data.pos[2] * .3 - 15) } })
  return <points ref={ref}><bufferGeometry><bufferAttribute attach="attributes-position" args={[positions, 3]} /></bufferGeometry><pointsMaterial size={.065} color="#9ddef2" transparent opacity={.45} sizeAttenuation depthWrite={false} /></points>
}
function BioGarden() {
  const matrices = useMemo(() => Array.from({ length: 180 }, (_, i) => { const o = new THREE.Object3D(); o.position.set((rand(i + 450) - .5) * 110, rand(i + 142) * 1.4, rand(i + 753) * -110 + 12); const s = .08 + rand(i + 87) * .2; o.scale.set(s, s * (3 + rand(i) * 6), s); o.updateMatrix(); return o.matrix }), [])
  return <instancedMesh args={[undefined, undefined, 180]} onUpdate={m => { matrices.forEach((matrix, i) => m.setMatrixAt(i, matrix)); m.instanceMatrix.needsUpdate = true }}><sphereGeometry args={[1, 5, 5]} /><meshStandardMaterial color="#3aabae" emissive="#12bcc6" emissiveIntensity={2.8} /></instancedMesh>
}
function Shafts({ zone }: { zone: number }) {
  return <group>{[0, 1, 2, 3].map(i => <mesh key={i} position={[18 + i * 14, 34, -30 - i * 11]} rotation={[0, 0, -.32]}><cylinderGeometry args={[.8, 9, 95, 12, 1, true]} /><meshBasicMaterial color={zone === 0 ? '#71c5d4' : '#277d97'} transparent opacity={zone === 0 ? .036 : .018} side={THREE.DoubleSide} depthWrite={false} blending={THREE.AdditiveBlending} /></mesh>)}</group>
}
function Submarine() {
  return <group position={[20, 5, -25]} rotation={[0, -.35, -.14]}>
    <mesh rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[5, 4.6, 27, 20, 1, true]} /><meshStandardMaterial color="#34444a" metalness={.8} roughness={.75} side={THREE.DoubleSide} /></mesh>
    <mesh position={[14, 0, 0]} rotation={[0, Math.PI / 2, 0]}><torusGeometry args={[4.65, .58, 8, 32]} /><meshStandardMaterial color="#69513a" metalness={.65} roughness={.65} /></mesh>
    <mesh position={[13.5, 0, 0]} rotation={[0, Math.PI / 2, 0]}><circleGeometry args={[4.5, 32]} /><meshStandardMaterial color="#020b10" side={THREE.DoubleSide} /></mesh>
    <mesh position={[-12, 0, 0]} scale={[5, 4.7, 4.7]}><sphereGeometry args={[1, 16, 12]} /><meshStandardMaterial color="#273d46" metalness={.7} roughness={.6} /></mesh>
    <mesh position={[-2, 6, 0]}><boxGeometry args={[7, 5, 3.5]} /><meshStandardMaterial color="#34434a" metalness={.8} roughness={.7} /></mesh>
    <mesh position={[-2, 9, 0]}><cylinderGeometry args={[.15, .15, 5, 6]} /><meshStandardMaterial color="#46606a" /></mesh>
    {[-9, -3, 3, 9].map(x => <group key={x}><mesh position={[x, 0, 0]} rotation={[0, Math.PI / 2, 0]}><torusGeometry args={[4.95, .12, 6, 24]} /><meshStandardMaterial color="#53626a" metalness={.8} roughness={.5} /></mesh><mesh position={[x, 2, 4.6]}><boxGeometry args={[1.5, .28, .2]} /><meshStandardMaterial color="#e7a365" emissive="#e97d32" emissiveIntensity={2} /></mesh></group>)}
    <pointLight position={[10, 1, 5]} color="#f18e47" intensity={35} distance={20} />
    <mesh position={[1, -2, 6]} rotation={[.2, 0, -.4]}><boxGeometry args={[14, .25, 6]} /><meshStandardMaterial color="#36464c" metalness={.7} roughness={.8} /></mesh>
  </group>
}
function Station() {
  return <group>
    <mesh position={[0, 1, -29]}><boxGeometry args={[13, 1, 31]} /><meshStandardMaterial color="#2b414a" metalness={.8} roughness={.55} /></mesh>
    {[-5.8, 5.8].map(x => <mesh key={x} position={[x, 5, -29]}><boxGeometry args={[1, 8, 29]} /><meshStandardMaterial color="#223943" metalness={.7} roughness={.7} /></mesh>)}
    {[-16, -22, -28, -34, -40].map((z, i) => <group key={z}><mesh position={[0, 8.7, z]}><boxGeometry args={[12, .5, .6]} /><meshStandardMaterial color="#465961" metalness={.8} /></mesh><mesh position={[4.9, 6, z]}><boxGeometry args={[.18, .16, 2.5]} /><meshStandardMaterial color="#96f1e6" emissive={i % 2 ? '#eaa15b' : '#48cdd2'} emissiveIntensity={2} /></mesh></group>)}
    <pointLight position={[0, 7, -30]} color="#61adbc" intensity={24} distance={26} />
    <mesh position={[-2.5, 2, -32]} rotation={[0, .6, .7]}><boxGeometry args={[1.2, 2.3, .7]} /><meshStandardMaterial color="#53606a" metalness={.7} /></mesh>
    <mesh position={[-2, 3, -32]}><sphereGeometry args={[.35, 8, 6]} /><meshStandardMaterial color="#bf7045" emissive="#ed6d33" emissiveIntensity={.6} /></mesh>
  </group>
}
function Ruins({ city }: { city: boolean }) {
  return <group>{Array.from({ length: city ? 16 : 8 }, (_, i) => { const side = i % 2 ? 1 : -1, x = side * (13 + rand(i + 4) * 26), z = -10 - Math.floor(i / 2) * 15, h = 12 + rand(i + 3) * 25; return <group key={i} position={[x, h / 2, z]} rotation={[0, Math.PI / 4, city ? 0 : (rand(i) - .5) * .3]}><mesh><boxGeometry args={[4.5, h, 4.5]} /><meshStandardMaterial color="#173139" metalness={.7} roughness={.4} /></mesh><mesh position={[0, 0, 2.27]}><boxGeometry args={[.12, h * .8, .03]} /><meshStandardMaterial color="#49e6d0" emissive="#21e6c8" emissiveIntensity={3} /></mesh><mesh position={[0, h / 2 + 1.5, 0]} rotation={[0, .8, 0]}><octahedronGeometry args={[2]} /><meshStandardMaterial color="#226274" emissive="#0e535e" emissiveIntensity={.7} metalness={.7} roughness={.3} /></mesh></group> })}
    <mesh position={[0, 13, city ? -46 : -31]}><torusGeometry args={[city ? 13 : 9, .65, 8, 40]} /><meshStandardMaterial color="#24484d" emissive="#126769" emissiveIntensity={.6} metalness={.8} roughness={.3} /></mesh>
    <pointLight position={[0, 13, -35]} color="#35d6c2" intensity={60} distance={45} />
  </group>
}
function ObjectModel({ object }: { object: WorldObject }) {
  const inner = useRef<THREE.Group>(null)
  const { kind, pos } = object
  const cyan = ['gate', 'return', 'refill'].includes(kind)
  const color = cyan ? '#80dedc' : '#ecad70'
  const discovered = game.data.discoveries.some(d => d.id === object.id)
  const visible = !object.hidden || discovered || Math.hypot(...pos.map((v, i) => v - game.data.pos[i])) < 12
  useFrame(({ clock }) => { if (inner.current) { inner.current.position.y = Math.sin(clock.elapsedTime * 1.3 + pos[0]) * .15; if (kind === 'core' || kind === 'ruin') inner.current.rotation.y += .004 } })
  if (!visible) return null
  return <group position={pos}>
    <group ref={inner}>
      {kind === 'gate' || kind === 'return' ? <><mesh rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[2.1, .09, 8, 32]} /><meshStandardMaterial color={color} emissive={color} emissiveIntensity={2} /></mesh><mesh><cylinderGeometry args={[.3, .6, 2.3, 8]} /><meshStandardMaterial color="#385b65" metalness={.8} /></mesh></> : kind === 'core' || kind === 'ruin' ? <mesh><octahedronGeometry args={[kind === 'core' ? 2.5 : 1.8]} /><meshStandardMaterial color="#59918e" emissive="#39b8a8" emissiveIntensity={1.2} metalness={.6} roughness={.2} wireframe={kind === 'core'} /></mesh> : <><mesh><boxGeometry args={kind === 'log' ? [.65, .18, .9] : kind === 'refill' ? [1.2, 2, 1.2] : [1.3, .9, 1]} /><meshStandardMaterial color={kind === 'supply' ? '#8b684c' : '#314f58'} metalness={.7} roughness={.55} /></mesh><mesh position={[0, .46, .1]} rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[.7, .45]} /><meshBasicMaterial color={color} /></mesh></>}
      <mesh position={[0, 2.3, 0]} rotation={[0, 0, Math.PI / 4]}><planeGeometry args={[.2, .2]} /><meshBasicMaterial color={color} side={THREE.DoubleSide} /></mesh>
    </group>
  </group>
}
function CreatureModel({ creature }: { creature: Creature }) {
  const ref = useRef<THREE.Group>(null), tail = useRef<THREE.Mesh>(null), last = useRef(new THREE.Vector3(...creature.pos))
  useFrame(({ clock }) => { if (!ref.current) return; const p = new THREE.Vector3(...creature.pos); ref.current.position.copy(p); const direction = p.clone().sub(last.current); if (direction.length() > .001) ref.current.rotation.y = Math.atan2(direction.x, direction.z); last.current.copy(p); if (tail.current) tail.current.rotation.y = Math.sin(clock.elapsedTime * 1.7) * .3 })
  const leviathan = creature.kind === 'leviathan', lantern = creature.kind === 'lantern'
  return <group ref={ref} position={creature.pos} scale={leviathan ? 1 : lantern ? .23 : .3}>
    <mesh scale={[3.1, 2.5, 12]}><sphereGeometry args={[1, 16, 12]} /><meshStandardMaterial color={leviathan ? '#102e3a' : '#213c4c'} roughness={.48} metalness={.35} /></mesh>
    <mesh position={[0, 0, 8]} scale={[3.3, 2, 3.8]}><sphereGeometry args={[1, 12, 8]} /><meshStandardMaterial color="#173b49" roughness={.6} /></mesh>
    <mesh ref={tail} position={[0, 1, -12]} scale={[.45, 5.5, 4]}><octahedronGeometry args={[1]} /><meshStandardMaterial color="#173644" /></mesh>
    {[-1, 1].map(side => <group key={side}><mesh position={[side * 3, -.4, 0]} rotation={[0, 0, side * -.7]} scale={[5, .3, 2.5]}><octahedronGeometry args={[1]} /><meshStandardMaterial color="#153946" /></mesh><mesh position={[side * 2.3, .8, 9.8]}><sphereGeometry args={[.18, 8, 6]} /><meshStandardMaterial color={lantern ? '#c3faff' : '#5dc6c9'} emissive={lantern ? '#adffec' : '#45d5cd'} emissiveIntensity={4} /></mesh></group>)}
    {Array.from({ length: 7 }, (_, i) => <mesh key={i} position={[0, 2.2, i * 2.4 - 8]} scale={[.35, 1.4, .8]}><octahedronGeometry args={[1]} /><meshStandardMaterial color="#398391" emissive="#258491" emissiveIntensity={.5} /></mesh>)}
    {lantern && <><mesh position={[0, 5, 10]}><sphereGeometry args={[1.6, 12, 8]} /><meshStandardMaterial color="#aafceb" emissive="#7cf8cb" emissiveIntensity={4} /></mesh><pointLight position={[0, 5, 10]} color="#71f8cb" intensity={12} distance={17} /></>}
  </group>
}
function FishSchool() {
  const group = useRef<THREE.Group>(null)
  useFrame(({ clock }) => { if (group.current) { group.current.position.x = Math.sin(clock.elapsedTime * .07) * 30; group.current.position.z = -30 + Math.cos(clock.elapsedTime * .07) * 12; group.current.rotation.y = clock.elapsedTime * .07 } })
  return <group ref={group} position={[0, 15, -30]}>{Array.from({ length: 14 }, (_, i) => <mesh key={i} position={[(rand(i) - .5) * 13, rand(i + 30) * 4, rand(i + 31) * 6]} scale={[.12, .25, .65]}><octahedronGeometry args={[1]} /><meshStandardMaterial color="#5e929e" metalness={.65} roughness={.35} /></mesh>)}</group>
}
function Rig() {
  const { camera, gl } = useThree(), light = useRef<THREE.SpotLight>(null), scan = useRef<THREE.Mesh>(null)
  const target = useMemo(() => new THREE.Object3D(), [])
  useFrame((_, delta) => {
    game.tick(delta)
    const d = game.data
    camera.position.set(...d.pos); camera.rotation.set(d.pitch, d.yaw, 0, 'YXZ'); camera.updateMatrixWorld()
    const label = document.getElementById('projected-objective'), objective = game.target
    if (label && objective) {
      const projected = new THREE.Vector3(objective.pos[0], objective.pos[1] + 3, objective.pos[2]).project(camera)
      label.style.display = projected.z < 1 && Math.abs(projected.x) < 1.1 && Math.abs(projected.y) < 1.1 ? 'block' : 'none'
      label.style.left = `${(projected.x * .5 + .5) * 100}%`; label.style.top = `${(-projected.y * .5 + .5) * 100}%`
    }
    if (light.current) { light.current.position.copy(camera.position); const direction = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion); target.position.copy(camera.position).add(direction.multiplyScalar(20)); target.updateMatrixWorld(); light.current.intensity = d.flashlight && d.battery > 0 ? 110 + d.upgrades.light * 45 : 0 }
    if (scan.current) { scan.current.visible = game.scanTime > 0; scan.current.position.set(...d.pos); scan.current.scale.setScalar(Math.max(.1, (2.5 - game.scanTime) * 20)); const m = scan.current.material as THREE.MeshBasicMaterial; m.opacity = game.scanTime * .065 }
    gl.domElement.dataset.ready = 'true'
  })
  return <><primitive object={target} /><spotLight ref={light} target={target} color="#b3e9e8" angle={.6} penumbra={.85} distance={65} decay={1.15} /><mesh ref={scan}><sphereGeometry args={[1, 24, 16]} /><meshBasicMaterial color="#63e7db" transparent opacity={.1} side={THREE.DoubleSide} depthWrite={false} /></mesh></>
}
function World() {
  useSyncExternalStore(game.subscribe, game.getSnapshot, game.getSnapshot)
  const zone = game.data.zone, z = ZONES[zone]
  return <><color attach="background" args={[z.color]} /><fogExp2 attach="fog" args={[z.color, z.fog]} /><ambientLight intensity={zone === 0 ? .65 : .33} color="#8cc5d4" /><directionalLight position={[20, 60, -20]} intensity={zone === 0 ? 1.5 : .55} color="#78bacb" />
    <Rig /><Terrain /><Rocks zone={zone} /><MarineSnow /><BioGarden /><Shafts zone={zone} />
    {zone === 0 && <><Submarine /><FishSchool /></>}{zone === 1 && <Station />}{zone >= 3 && <Ruins city={zone === 4} />}
    {game.activeObjects.map(o => <ObjectModel key={o.id} object={o} />)}{game.creatures.map(c => <CreatureModel key={c.id} creature={c} />)}
  </>
}
class GraphicsBoundary extends Component<{ children: ReactNode }, { error: boolean }> {
  state = { error: false }
  static getDerivedStateFromError() { return { error: true } }
  render() { return this.state.error ? <div className="graphics-error"><h2>Graphics unavailable</h2><p>This dive requires WebGL. Enable hardware acceleration or use a current Chrome, Safari, or Firefox browser.</p><button onClick={() => window.location.reload()}>Retry launch</button></div> : this.props.children }
}
export default function OceanScene({ lowQuality }: { lowQuality: boolean }) {
  return <GraphicsBoundary><Canvas className="ocean-canvas" dpr={lowQuality ? 1 : [1, 1.5]} camera={{ fov: 72, near: .1, far: 200 }} gl={{ antialias: !lowQuality, alpha: false, powerPreference: 'high-performance' }} onCreated={({ gl }) => { gl.setClearColor('#061b29'); gl.toneMapping = THREE.ACESFilmicToneMapping; gl.toneMappingExposure = 1.2 }}><World /></Canvas></GraphicsBoundary>
}
